import React from "react";


export default function DataShowing() {
  return (
    <div>
      <h1 style={{ color: "white" }}>DataShowing</h1>
    </div>
  );
}
