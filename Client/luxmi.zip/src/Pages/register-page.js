import Navbar from "../Components/Navbar/navbar";
import User from "../Components/User/user";

export default function Register() {
    return (
        <div>
            <Navbar />
            <User />
        </div>
    );
}